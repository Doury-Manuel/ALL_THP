# Data_scientist
THP semaine 2 _ projet data scientist
