# exo_13.rb
puts "quel est ton année de naissance ?"
annee = gets.to_i
annee.upto(2020) {
    puts annee
    annee +=1 } 