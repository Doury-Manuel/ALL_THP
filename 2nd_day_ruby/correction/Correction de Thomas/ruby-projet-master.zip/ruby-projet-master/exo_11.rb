# exo_11.rb
puts "Ecris un nombre"
nombres = gets.chomp.to_i
nombres.times do
  puts "Salut, ça farte ?"
end