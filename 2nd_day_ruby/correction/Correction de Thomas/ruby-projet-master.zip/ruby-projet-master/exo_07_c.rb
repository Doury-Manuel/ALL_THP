# exo_07.c.rb
user_name = gets.chomp
puts user_name

# l'exo 07/a, Il pause une question puis demande l'user.name de la personne pour lui donenr ensuite avec "puts user_name"
# l'exo 07/b, il pause une question. A la suite un "prints + > pour que le > s'affiche quand l'user écrira son nom"
# l'exo 07/c, pas de question juste l'user_name à donner puis il donne l'user_name