# exo_03.rb
# puts "Bonjour, monde !"
# le # affiche un commentaire donc le programme ne s'applique pas
puts "Et avec une voix sexy, ça donne : Bonjour, monde !"