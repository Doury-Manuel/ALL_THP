# exo_02.rb
puts "Bonjour, monde !"
puts "Et avec une voix sexy, ça donne : Bonjour, monde !"