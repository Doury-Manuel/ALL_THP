# exo_12.rb
puts "Tape un nombre entier"
nombre = gets.chomp.to_i
nombre.times do |index|
  puts index
end