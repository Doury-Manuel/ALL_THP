# exo_01.rb
puts "Bonjour, monde !"