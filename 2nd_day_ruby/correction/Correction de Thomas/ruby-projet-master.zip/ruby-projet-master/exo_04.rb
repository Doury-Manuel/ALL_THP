# exo_04.rb
puts "Salut, ça farte ?"

# le programme dit "Salut, ça farte" après un puts