liste_emails = Array.new(50)

50.times do |i|
  liste_emails[i] = "jean.dupont.#{i}@email.fr"
  puts "jean.dupont.#{i}@email.fr"

end
