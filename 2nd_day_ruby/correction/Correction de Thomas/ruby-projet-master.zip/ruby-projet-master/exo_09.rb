puts "Votre prénom?"
user_name = gets.chomp
puts "Votre nom maintenant"
first_name = gets.chomp
print "Bonjour " 
print user_name
print first_name