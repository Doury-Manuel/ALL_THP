puts "Quel est ton prénom"
print ">"
user_name = gets.chomp
print "Bonjour" 
puts user_name