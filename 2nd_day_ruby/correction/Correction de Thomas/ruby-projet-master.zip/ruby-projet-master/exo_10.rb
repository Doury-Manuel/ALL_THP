puts "annee?"
birthday = gets.chomp.to_i
puts 2020 - birthday -3