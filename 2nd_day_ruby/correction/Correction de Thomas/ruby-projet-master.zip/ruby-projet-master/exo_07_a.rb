# exo_07_a.rb
puts "Bonjour, c'est quoi ton blase ?"
user_name = gets.chomp
puts user_name

# le .chomp s'applique à une chaîne de caractères et supprime ce /n