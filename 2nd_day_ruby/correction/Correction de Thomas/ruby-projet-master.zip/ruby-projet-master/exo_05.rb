# exo_05.rb
# puts pour afficher un texte 
puts "On va compter le nombre d'heures de travail à THP"
# c'est une multiplication en temps de travail (10 x 5 x 11)
puts "Travail : #{10 * 5 * 11}"
# 10 x 5 x 11 x 60 pour le temps en minutes
puts "En minutes ça fait : #{10 * 5 * 11 * 60}"
# calucul pour le nombre de secondes
puts "Et en secondes ?"

puts 10 * 5 * 11 * 60 * 60
# 3 + 2 = 5 & 5 - 7 = 2 / c'est pour savoir si 5 est infèrieur à 2
puts "Est-ce que c'est vrai que 3 + 2 < 5 - 7 ?"

puts 3 + 2 < 5 - 7
# # calcule + le résultat
puts "Ça fait combien 3 + 2 ? #{3 + 2}"
puts "Ça fait combien 5 - 7 ? #{5 - 7}"
# texte 
puts "Ok, c'est faux alors !"

puts "C'est drôle ça, faisons-en plus :"
# question/ texte + le résultat de calcul + infèrieur ou supérieur et ça affiche le résultat
puts "Est-ce que 5 est plus grand que -2 ? #{5 > -2}"
puts "Est-ce que 5 est supérieur ou égal à -2 ? #{5 >= -2}"
puts "Est-ce que 5 est inférieur ou égal à -2 ? #{5 <= -2}"

# le #{} est la pour écrire sur la même ligne d'un puts ou d'un print