puts "Salutations, Mousaillon ! Quel est ton nom ?"
print ">"
user_name = gets.chomp 
puts "Bonjour, #{user_name} !"