puts "salut, ça farte ?
#ne fonctionne pas car non fermée