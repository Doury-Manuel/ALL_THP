puts "En quelle année es-tu né ?"
print ">"
user_age = gets.chomp
puts "En 2017 tu avais donc #{2017 - user_age.to_i} ans"