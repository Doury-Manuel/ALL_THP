puts "Bonjour, monde !"
#puts "Et avec une voix sexy, ça donne : Bonjour, monde !"
#puts n'est pas executable, c'est un commentaire, comme celui-ci !