puts "Salutations, Mousaillon ! Quel est ton prénom ?"
print ">"
user_first_name = gets.chomp 
puts "Et quel est ton nom ?"
print ">"
user_last_name = gets.chomp
puts "D'accord, alors bonjour #{user_first_name} #{user_last_name} !"
