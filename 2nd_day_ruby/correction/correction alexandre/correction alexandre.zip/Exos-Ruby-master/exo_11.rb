puts "Choisissez un nombre"
print ">"
number = gets.chomp
number.to_i.times {puts "Salut ça farte"}

