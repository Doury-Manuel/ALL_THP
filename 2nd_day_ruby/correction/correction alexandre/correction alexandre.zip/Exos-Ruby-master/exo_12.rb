puts "Choisissez un nombre"
print ">"
number = gets.chomp.to_i

i = 0 

while i<number
	puts i + 1
	i +=1 

end