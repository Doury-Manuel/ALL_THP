puts "Bonjour, c'est quoi ton blase ?"
user_name = gets.chomp
puts user_name
#permet à l'utilisateur de saisir des données