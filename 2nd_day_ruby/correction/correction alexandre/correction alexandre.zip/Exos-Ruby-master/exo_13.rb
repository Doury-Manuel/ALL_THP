puts "Quelle est ton année de naissance ?"

print ">"

year = gets.chomp.to_i

while year<=2020

	puts year
	year +=1

end
