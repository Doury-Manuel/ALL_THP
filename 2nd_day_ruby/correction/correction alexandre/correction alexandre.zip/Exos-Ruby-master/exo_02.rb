puts "Bonjour, monde !"
puts "Et avec une voix sexy, ça donne : Bonjour, monde !"