puts "On va compter le nombre d'heures de travail à THP"
puts "Travail : #{10 * 5 * 11}" #calcul du nombre d'heures sur une base heures * jours * semaines
puts "En minutes ça fait : #{10 * 5 * 11 * 60}" # heures*jours*semaines*minutes

puts "Et en secondes ?"

puts 10 * 5 * 11 * 60 * 60 # heures*jours*semaines*minutes*secondes

puts "Est-ce que c'est vrai que 3 + 2 < 5 - 7 ?"

puts 3 + 2 < 5 - 7 #on lui demande de vérifier la véracité de la ligne de calcul proposée --> 5<2 = false

puts "Ça fait combien 3 + 2 ? #{3 + 2}" #effectue les calculs demandés
puts "Ça fait combien 5 - 7 ? #{5 - 7}" #idem

puts "Ok, c'est faux alors !"

puts "C'est drôle ça, faisons-en plus :"

puts "Est-ce que 5 est plus grand que -2 ? #{5 > -2}" #répond aux questions en executant les booléens
puts "Est-ce que 5 est supérieur ou égal à -2 ? #{5 >= -2}"
puts "Est-ce que 5 est inférieur ou égal à -2 ? #{5 <= -2}"